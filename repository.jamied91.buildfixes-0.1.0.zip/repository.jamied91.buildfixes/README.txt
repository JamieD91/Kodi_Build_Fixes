Install this ZIP in Kodi, then browse Jamie Build Fixes Repository / Program add-ons.
